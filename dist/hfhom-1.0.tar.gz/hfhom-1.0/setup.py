from distutils.core import setup

setup(
        name='hfhom',
        version='1.0',
        packages=['CorrTerms',],
        license='GNU General Public License',
        long_description=open('README.md').read(),
)
